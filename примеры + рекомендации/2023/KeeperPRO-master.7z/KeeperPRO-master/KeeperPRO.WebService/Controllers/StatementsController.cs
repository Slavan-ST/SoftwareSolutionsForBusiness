﻿using KeeperPRO.WebService.Data;
using KeeperPRO.WebService.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace KeeperPRO.WebService.Controllers
{
    public class StatementsController : Controller
    {
        static HttpClient? httpClient;
        private KeeperContext _context;
        public StatementsController(KeeperContext db)
        {
            _context = db;
            #region Http client create
            var socketsHandler = new SocketsHttpHandler
            {
                PooledConnectionLifetime = TimeSpan.FromMinutes(32)
            };
            httpClient = new HttpClient(socketsHandler); 
            #endregion
        }

        #region Все заявки
        // GET: StatementsController
        public async Task<ActionResult> Index()
        {

            List<Statement>? statements = await httpClient.GetFromJsonAsync<List<Statement>>("https://localhost:7066/api/statements");
            if (statements != null)
            {
                foreach (var state in statements)
                {
                    Console.WriteLine(state.Id);
                }
            }

            //var count = statements.Count();

            return View("ShowAll", statements);
        }
        #endregion

        #region Найти заявку
        // GET: StatementsController/Statement/5
        public async Task<ActionResult> Statement(int id)
        {
            Statement? state = await httpClient.GetFromJsonAsync<Statement>($"https://localhost:7066/api/statements/{id}");

            return View("Show", state as Statement);
        }
        #endregion

        #region Создать заявку
        // GET: StatementsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StatementsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Statement state)
        {
            try
            {
                _context.Statements.Add(state);
                _context.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        #endregion

        #region Редактировать заявку
        // GET: StatementsController/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            Statement? state = await httpClient.GetFromJsonAsync<Statement>($"https://localhost:7066/api/statements/{id}");

            return View(state as Statement);

        }

        // POST: StatementsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Statement state)
        {
            try
            {
                _context.Statements.Update(state);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        #endregion

        #region Удалить заявку
        // GET: StatementsController/Delete/5
        public async Task<ActionResult> Delete(int id)
        {

            Statement? state = await httpClient.GetFromJsonAsync<Statement>($"https://localhost:7066/api/statements/{id}");

            if (state != null)
            {
                _context.Statements.Remove(state);
                _context.SaveChanges();
            }

            return RedirectToAction("Index"); // View("ShowAll");
        }
        #endregion

        #region Поиск заявки по id
        // GET: StatementsController/SearchStatement
        public async Task<ActionResult> SearchStatement(long id) // id user
        {
            List<Statement>? statementsUser = await httpClient.GetFromJsonAsync<List<Statement>>($"https://localhost:7066/api/statements/search/{id}");
            if (statementsUser != null)
            {
                foreach (var state in statementsUser)
                {
                    Console.WriteLine(state.Id);
                }
            }

            return View("ShowStatementsUser", statementsUser);
        }
        #endregion

    }
}
