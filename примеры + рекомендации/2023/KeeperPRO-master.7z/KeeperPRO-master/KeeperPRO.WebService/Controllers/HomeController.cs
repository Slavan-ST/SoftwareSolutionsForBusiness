﻿using KeeperPRO.WebService.Data;
using KeeperPRO.WebService.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Linq;

namespace KeeperPRO.WebService.Controllers
{
    public class HomeController : Controller
    {
        private KeeperContext db;
        public HomeController(KeeperContext dataContext)
        {
            db = dataContext;
        }

        #region Регистрация
        public IActionResult Sign()
        {
            // sign

            return View("Sign");
        }

        [HttpPost]
        public IActionResult Sign(User user)
        {

            ViewBag.CountUser = db.Users.Count();
            db.Users.Add(user);
            db.SaveChanges();

            return View("Sign");
        }
        #endregion

        #region Авторизация
        public IActionResult Auth()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Auth(User user)
        {
            User currentUser = db.Users.Where(u => u.Login == user.Login && u.Password == user.Password).FirstOrDefault<User>();

            if (currentUser is not null)
            {
                ViewBag.User = currentUser;
                ViewBag.Login = currentUser.Login;
                return View("Index");
            }
            else
            {
                return View();
            }

        } 
        #endregion

        public IActionResult Index()
        {
            return View();
        }

    }
}