﻿using System;
using System.Collections.Generic;
using Keeper.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Keeper.API.Data;

public partial class KeeperContext : DbContext
{
    public KeeperContext()
    {
    }

    public KeeperContext(DbContextOptions<KeeperContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Statement> Statements { get; set; }

    public virtual DbSet<User> Users { get; set; }

    //тут подключение к БД, естественно, что если использовать sql, то подключение будет - optionsBuilder.UseSqlServer....
    //    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) =>
    //      optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=Keeper;Username=postgres;Password=root");


    //настройка таблиц  (у меня обычно дефолтные)
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Statement>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("statements_pk");  //задаём первичный ключ

            entity.ToTable("statements");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Attachfile).HasColumnName("attachfile");
            entity.Property(e => e.Begindate).HasColumnName("begindate");
            entity.Property(e => e.Birthday).HasColumnName("birthday");
            entity.Property(e => e.Company)
                .HasColumnType("character varying")
                .HasColumnName("company");
            entity.Property(e => e.Email)
                .HasColumnType("character varying")
                .HasColumnName("email");
            entity.Property(e => e.Employ)
                .HasColumnType("character varying")
                .HasColumnName("employ");
            entity.Property(e => e.Enddate).HasColumnName("enddate");
            entity.Property(e => e.Name)
                .HasColumnType("character varying")
                .HasColumnName("name");
            entity.Property(e => e.Note)
                .HasColumnType("character varying")
                .HasColumnName("note");
            entity.Property(e => e.Passportnumber)
                .HasColumnType("character varying")
                .HasColumnName("passportnumber");
            entity.Property(e => e.Passportserial)
                .HasColumnType("character varying")
                .HasColumnName("passportserial");
            entity.Property(e => e.Patronimic)
                .HasColumnType("character varying")
                .HasColumnName("patronimic");
            entity.Property(e => e.Phone)
                .HasColumnType("character varying")
                .HasColumnName("phone");
            entity.Property(e => e.Photo)
                .HasColumnType("character varying")
                .HasColumnName("photo");
            entity.Property(e => e.Status)
                .HasColumnType("character varying")
                .HasColumnName("status");
            entity.Property(e => e.Subdivision)
                .HasColumnType("character varying")
                .HasColumnName("subdivision");
            entity.Property(e => e.Surname)
                .HasColumnType("character varying")
                .HasColumnName("surname");
            entity.Property(e => e.Target)
                .HasColumnType("character varying")
                .HasColumnName("target");
            entity.Property(e => e.Group)
              .HasColumnType("character varying")
              .HasColumnName("group");


        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("users_pk");

            entity.ToTable("users");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Email)
                .HasColumnType("character varying")
                .HasColumnName("email");
            entity.Property(e => e.Login)
                .HasColumnType("character varying")
                .HasColumnName("login");
            entity.Property(e => e.Password)
                .HasColumnType("character varying")
                .HasColumnName("password");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
